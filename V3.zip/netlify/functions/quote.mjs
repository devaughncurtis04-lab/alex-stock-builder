export default async (request) => {
  const symbol = new URL(request.url).searchParams.get("symbol")?.toUpperCase();
  if (!symbol || !/^[A-Z.]{1,10}$/.test(symbol)) {
    return new Response(JSON.stringify({ error: "Invalid symbol" }), { status: 400, headers: {"content-type":"application/json"} });
  }

  const key = process.env.ALPHA_VANTAGE_API_KEY;
  if (!key) {
    return new Response(JSON.stringify({ error: "ALPHA_VANTAGE_API_KEY is not configured in Netlify." }), { status: 503, headers: {"content-type":"application/json"} });
  }

  const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(symbol)}&apikey=${encodeURIComponent(key)}`;
  const res = await fetch(url);
  const data = await res.json();
  const q = data["Global Quote"];

  if (!q || !q["05. price"]) {
    return new Response(JSON.stringify({ error: data["Note"] || data["Information"] || "No quote returned" }), { status: 502, headers: {"content-type":"application/json"} });
  }

  return new Response(JSON.stringify({
    symbol,
    price: Number(q["05. price"]),
    change: Number((q["10. change percent"] || "0").replace("%","")),
    open: Number(q["02. open"]),
    high: Number(q["03. high"]),
    low: Number(q["04. low"]),
    volume: Number(q["06. volume"]),
    previousClose: Number(q["08. previous close"]),
    latestTradingDay: q["07. latest trading day"]
  }), { headers: {"content-type":"application/json","cache-control":"public,max-age=30"} });
};
