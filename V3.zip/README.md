# Alex's Stock Builder

A modern, beginner-friendly stock research dashboard built with React + Vite and designed for GitHub + Netlify.

## Features

- Compact modern top navigation
- Working Home / Research / Market / Discover navigation
- Less-used tools under **More**
- Research workflow for watchlist stocks
- Charts, company numbers, technical signals, portfolio/risk, journal and learning pages
- Demo fallback data
- Optional live quotes through a Netlify Function
- No brokerage credentials or private API keys in the client

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Netlify live data

In Netlify, add an environment variable:

`ALPHA_VANTAGE_API_KEY`

The browser calls `/.netlify/functions/quote`, and the function calls the provider. Do not commit the API key to GitHub.

## Open source

MIT licensed. Pull requests and improvements are welcome.

Educational software only; not financial advice.
