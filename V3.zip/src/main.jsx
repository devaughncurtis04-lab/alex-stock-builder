import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const DEMO = [
  { symbol:"NVDA", name:"NVIDIA", price:183.42, change:2.41, signal:"Bullish", risk:"Medium" },
  { symbol:"AAPL", name:"Apple", price:229.41, change:1.28, signal:"Watch", risk:"Low" },
  { symbol:"MSFT", name:"Microsoft", price:511.80, change:.47, signal:"Core", risk:"Low" },
  { symbol:"AMAT", name:"Applied Materials", price:246.18, change:1.84, signal:"Watch", risk:"Medium" },
  { symbol:"SPY", name:"S&P 500 ETF", price:701.12, change:.64, signal:"Core", risk:"Low" },
];

const chart = [42,48,45,53,50,57,61,58,66,70,68,76,81,79,88,93,91,98,104,109];

function LineChart(){
  const pts=chart.map((v,i)=>`${i*(100/(chart.length-1))},${120-v}`).join(" ");
  return <svg viewBox="0 0 100 125" preserveAspectRatio="none" className="chart">
    <defs><linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0%" stopColor="#58d6a0" stopOpacity=".28"/><stop offset="100%" stopColor="#58d6a0" stopOpacity="0"/>
    </linearGradient></defs>
    <polygon points={`0,125 ${pts} 100,125`} fill="url(#g)"/>
    <polyline points={pts} fill="none" stroke="#58d6a0" strokeWidth="2.4" vectorEffect="non-scaling-stroke"/>
  </svg>;
}

async function fetchQuote(symbol){
  const r=await fetch(`/.netlify/functions/quote?symbol=${encodeURIComponent(symbol)}`);
  if(!r.ok) throw new Error("Live quote unavailable");
  const d=await r.json();
  if(!d.price) throw new Error(d.error || "No quote returned");
  return d;
}

function App(){
  const [page,setPage]=useState("home");
  const [selected,setSelected]=useState("NVDA");
  const [search,setSearch]=useState("");
  const [more,setMore]=useState(false);
  const [quote,setQuote]=useState(null);
  const [liveState,setLiveState]=useState("demo");
  const [cash,setCash]=useState(50);
  const [completed,setCompleted]=useState(false);

  const stock = quote?.symbol===selected ? quote : DEMO.find(x=>x.symbol===selected)||DEMO[0];
  const filtered = useMemo(()=>DEMO.filter(s=>`${s.symbol} ${s.name}`.toLowerCase().includes(search.toLowerCase())),[search]);

  async function loadLive(symbol=selected){
    setSelected(symbol); setLiveState("loading");
    try{ const q=await fetchQuote(symbol); setQuote(q); setLiveState("live"); }
    catch{ setQuote(null); setLiveState("demo"); }
  }

  function navigate(id){ setPage(id); setMore(false); window.scrollTo({top:0,behavior:"smooth"}); }

  const buy=()=>{if(cash>=10)setCash(c=>+(c-10).toFixed(2));};

  return <div className="app">
    <header className="topbar">
      <div className="top-left">
        <div className="brand"><span className="brand-mark">A</span><span>Alex's <b>Stock Builder</b></span></div>
        <nav className="nav">
          <button className={page==="home"?"active":""} onClick={()=>navigate("home")}>Home</button>
          <button className={page==="research"?"active":""} onClick={()=>navigate("research")}>Research</button>
          <button className={page==="market"?"active":""} onClick={()=>navigate("market")}>Market</button>
          <button className={page==="discover"?"active":""} onClick={()=>navigate("discover")}>Discover</button>
          <div className="more">
            <button className={more?"active":""} onClick={()=>setMore(v=>!v)}>More ▾</button>
            {more&&<div className="menu">
              {[
                ["charts","Charts"],["numbers","Company Numbers"],["signals","Chart Signals"],
                ["portfolio","Portfolio & Risk"],["journal","Journal"],["learn","Learn"],["settings","Settings"]
              ].map(([id,label])=><button key={id} onClick={()=>navigate(id)}>{label}</button>)}
            </div>}
          </div>
        </nav>
      </div>
      <div className="status"><span className={liveState==="live"?"dot live":"dot"}></span>{liveState==="live"?"LIVE DATA":"DEMO DATA"}</div>
    </header>

    <main>
      {page==="home" && <Home stock={stock} cash={cash} setPage={navigate} completed={completed} setCompleted={setCompleted} onSelect={loadLive}/>}
      {page==="research" && <Research stock={stock} search={search} setSearch={setSearch} filtered={filtered} onSelect={loadLive}/>}
      {page==="market" && <Market onSelect={loadLive} selected={selected}/>}
      {page==="discover" && <Discover onSelect={loadLive}/>}
      {page==="charts" && <Charts stock={stock}/>}
      {page==="numbers" && <Numbers stock={stock}/>}
      {page==="signals" && <Signals stock={stock}/>}
      {page==="portfolio" && <Portfolio cash={cash} setCash={setCash} buy={buy}/>}
      {page==="journal" && <Journal/>}
      {page==="learn" && <Learn/>}
      {page==="settings" && <Settings liveState={liveState} onTest={()=>loadLive(selected)} />}
    </main>
    <button className="help" onClick={()=>alert("Start with Research → choose a stock → Chart → Company Numbers → Signals → AI/notes. Live quotes require the Netlify server function and ALPHA_VANTAGE_API_KEY.")}>?</button>
    <footer>Alex's Stock Builder • Open source • Educational use only — not financial advice.</footer>
  </div>
}

function Header({eyebrow,title,sub,children}){return <div className="page-head"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{sub}</p></div><div>{children}</div></div>}

function Home({stock,cash,setPage,completed,setCompleted,onSelect}){
  return <>
    <Header eyebrow="YOUR INVESTING HOME" title="Learn the market without the overwhelm." sub="One simple workflow: find a company, understand it, check the chart, then decide what you think." />
    <section className="hero-grid">
      <div className="hero card">
        <div className="eyebrow">START HERE</div><h2>Research one stock in 5 minutes.</h2>
        <p>Pick a company, read the basics, look at price behavior, then write down your reason before you paper trade.</p>
        <button className="primary" onClick={()=>setPage("research")}>Research a stock →</button>
      </div>
      <div className="card">
        <div className="section"><span>Paper portfolio</span><span className="pill">Beginner</span></div>
        <strong className="big">$50.00</strong><div className="positive">+$0.00 today</div>
        <div className="kpis"><div><small>Cash</small><b>${cash.toFixed(2)}</b></div><div><small>Risk</small><b>LOW</b></div></div>
      </div>
    </section>
    <section className="grid3">
      <div className="card clickable" onClick={()=>setPage("research")}><span className="icon">🔎</span><h3>Find a stock</h3><p>Search your watchlist and open a company.</p></div>
      <div className="card clickable" onClick={()=>setPage("charts")}><span className="icon">📈</span><h3>Read a chart</h3><p>Start with trend and price before indicators.</p></div>
      <div className="card clickable" onClick={()=>setPage("learn")}><span className="icon">📚</span><h3>Learn one concept</h3><p>Understand P/E, RSI, earnings and more.</p></div>
    </section>
    <section className="layout">
      <div className="card"><div className="section"><span>Today's assignment</span><span className="pill">DAY 1</span></div><h3>Read the market, don't chase it.</h3><p>Pick one stock and explain why you would buy, wait, or avoid it.</p>
        <label className="check"><input type="checkbox" checked={completed} onChange={e=>setCompleted(e.target.checked)}/> I completed today's assignment</label>
      </div>
      <div className="card"><div className="section"><span>Featured stock</span><span className="badge live">● WATCH</span></div><div className="stockline"><b>{stock.symbol}</b><span>{stock.name}</span><strong>${Number(stock.price).toFixed(2)}</strong><em className="positive">{Number(stock.change)>=0?"+":""}{Number(stock.change).toFixed(2)}%</em></div>
      <button className="secondary" onClick={()=>onSelect(stock.symbol)}>Refresh live quote</button></div>
    </section>
  </>
}

function Research({stock,search,setSearch,filtered,onSelect}){
  return <>
    <Header eyebrow="RESEARCH" title="Understand the company first." sub="Choose a stock, then move through the simple research checklist."/>
    <div className="searchbar"><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search AAPL, NVDA, MSFT..." /><button className="primary" onClick={()=>onSelect(search.toUpperCase())}>Get live quote</button></div>
    <div className="layout">
      <div className="card"><div className="section"><span>Watchlist</span><span className="pill">{filtered.length} stocks</span></div>
        {filtered.map(s=><button className={`watch ${s.symbol===stock.symbol?"selected":""}`} key={s.symbol} onClick={()=>onSelect(s.symbol)}><b>{s.symbol}</b><span>{s.name}</span><strong>${s.price.toFixed(2)}</strong><em className={s.change>=0?"positive":"negative"}>{s.change>=0?"+":""}{s.change.toFixed(2)}%</em></button>)}
      </div>
      <div className="card"><div className="section"><span>{stock.symbol} · {stock.name}</span><span className="badge">RESEARCH</span></div><strong className="price">${Number(stock.price).toFixed(2)}</strong><div className="positive">{Number(stock.change)>=0?"+":""}{Number(stock.change).toFixed(2)}%</div><div className="checklist">
        <div>✓ Business quality <span>What does the company actually sell?</span></div><div>✓ Growth <span>Are sales and profits improving?</span></div><div>✓ Valuation <span>What expectations are already priced in?</span></div><div>✓ Risks <span>What could make the thesis wrong?</span></div>
      </div></div>
    </div>
  </>
}

function Market({onSelect,selected}){return <>
  <Header eyebrow="MARKET" title="Market overview." sub="Use the market as context, not as a reason to chase a trade."/>
  <div className="grid4">{[["S&P 500","5,990.4","+0.82%"],["NASDAQ","19,420.1","+1.14%"],["Dow Jones","44,180.2","+0.31%"],["VIX","18.4","-2.1%"]].map(x=><div className="card" key={x[0]}><small>{x[0]}</small><strong className="value">{x[1]}</strong><span className={x[2][0]==="-"?"negative":"positive"}>{x[2]}</span></div>)}</div>
  <div className="layout"><div className="card"><div className="section"><span>Market trend</span><span className="pill">Demo context</span></div><div className="chart large"><LineChart/></div></div><div className="card"><div className="section"><span>Quick watch</span></div>{DEMO.slice(0,4).map(s=><button className="watch" key={s.symbol} onClick={()=>onSelect(s.symbol)}><b>{s.symbol}</b><span>{s.name}</span><em className="positive">+{s.change.toFixed(2)}%</em></button>)}</div></div>
</>}

function Discover({onSelect}){return <>
  <Header eyebrow="DISCOVER" title="Find ideas worth researching." sub="These are prompts for research, not buy signals."/>
  <div className="grid3">{[
    ["Momentum","Stocks showing stronger recent price movement.","CRWV"],
    ["Quality","Large, established businesses to study.","MSFT"],
    ["Semiconductors","A sector to learn through several companies.","NVDA"]
  ].map(x=><div className="card" key={x[0]}><span className="pill">{x[0]}</span><h3>{x[1]}</h3><button className="secondary" onClick={()=>onSelect(x[2])}>Research {x[2]}</button></div>)}</div>
</>}

function Charts({stock}){return <>
  <Header eyebrow="CHARTS" title={`${stock.symbol} price chart`} sub="Start with trend and timeframe. Indicators come second."/>
  <div className="card"><div className="chart large"><LineChart/></div><div className="chart-labels"><span>6 months ago</span><span>Today</span></div></div>
  <div className="grid3"><div className="card"><b>Trend</b><p className="positive">Upward in this demo</p><small>Look for higher highs and higher lows.</small></div><div className="card"><b>Support</b><p>$165–$170</p><small>Illustrative zone, not a prediction.</small></div><div className="card"><b>Resistance</b><p>$190–$195</p><small>Illustrative zone, not a prediction.</small></div></div>
</>}

function Numbers({stock}){const metrics=[["P/E","34.2x","How much investors pay for each $1 of earnings."],["Revenue growth","8.1%","How quickly sales are changing."],["Profit margin","24.1%","How much revenue becomes profit."],["Debt / equity","0.32","A snapshot of financial leverage."]];return <>
  <Header eyebrow="COMPANY NUMBERS" title={`${stock.symbol} fundamentals`} sub="Don't judge a company from one metric. Compare trends, peers, and valuation."/>
  <div className="grid4">{metrics.map(m=><div className="card" key={m[0]}><small>{m[0]}</small><strong className="value">{m[1]}</strong><p>{m[2]}</p></div>)}</div>
</>}

function Signals({stock}){return <>
  <Header eyebrow="CHART SIGNALS" title={`${stock.symbol} technical picture`} sub="Indicators describe price behavior. They don't tell you whether a business is good."/>
  <div className="grid3">{[["Trend","Bullish","Price is above the illustrative moving average."],["RSI","58","Neutral-to-positive momentum zone."],["Volume","Above average","Participation is elevated in this demo."]].map(m=><div className="card" key={m[0]}><small>{m[0]}</small><strong className="value">{m[1]}</strong><p>{m[2]}</p></div>)}</div>
</>}

function Portfolio({cash,setCash,buy}){return <>
  <Header eyebrow="PORTFOLIO & RISK" title="Paper trade while you learn." sub="No leverage. Keep position sizes small. Track the reason for every trade."/>
  <div className="grid4"><div className="card"><small>Portfolio value</small><strong className="value">$50.00</strong></div><div className="card"><small>Available cash</small><strong className="value">${cash.toFixed(2)}</strong></div><div className="card"><small>Risk</small><strong className="value positive">LOW</strong></div><div className="card"><small>Leverage</small><strong className="value">0x</strong></div></div>
  <div className="card" style={{marginTop:14}}><div className="section"><span>Practice trade</span><span className="pill">Paper only</span></div><p>Simulate a $10 purchase to practice position sizing.</p><button className="primary" onClick={buy}>Simulate $10 buy</button></div>
</>}

function Journal(){const [text,setText]=useState("");return <><Header eyebrow="JOURNAL" title="Write your thesis." sub="A good journal entry explains what you believe and what would prove you wrong."/><div className="card"><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Why would I own this stock? What are the risks? What would change my mind?" rows="12"/><div className="actions"><button className="primary" onClick={()=>localStorage.setItem("asb-journal",text)}>Save note</button><span className="small">Saved locally in this browser.</span></div></div></>}

function Learn(){return <><Header eyebrow="LEARN" title="Build your investing vocabulary." sub="Short explanations designed for beginners."/><div className="grid3">{[
["P/E","Price-to-earnings compares the stock price with earnings."],
["RSI","A momentum indicator. It can help describe recent buying and selling strength."],
["Earnings","A company's reported results can change expectations and the stock price."],
["Free cash flow","Cash left after the company funds its operations and capital spending."],
["Market cap","The market value of all outstanding shares."],
["Diversification","Spreading exposure so one company does not dominate your risk."]
].map(x=><div className="card" key={x[0]}><span className="pill">BEGINNER</span><h3>{x[0]}</h3><p>{x[1]}</p></div>)}</div></>}

function Settings({liveState,onTest}){return <><Header eyebrow="SETTINGS" title="Data & preferences." sub="Live quotes are requested through the Netlify server function."/><div className="layout"><div className="card"><div className="section"><span>Market data</span><span className={liveState==="live"?"badge live":"badge"}>{liveState==="live"?"● LIVE":"● DEMO"}</span></div><p>Set <code>ALPHA_VANTAGE_API_KEY</code> in Netlify environment variables. Never commit the key to GitHub.</p><button className="primary" onClick={onTest}>Test live AAPL quote</button></div><div className="card"><div className="section"><span>Interface</span></div><p>Modern compact navigation is enabled. Less-used tools live under <b>More ▾</b>.</p><p className="small">Open source • React • Vite • Netlify-ready</p></div></div></>}

createRoot(document.getElementById("root")).render(<App/>);
